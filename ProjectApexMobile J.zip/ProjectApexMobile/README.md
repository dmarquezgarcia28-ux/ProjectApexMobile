# Project Apex Mobile

Prototipo original de carreras 3D para Android, creado con Godot 4.3. Esta primera versión usa geometría simple generada por código: coche, circuito ovalado, cámara de persecución y controles táctiles.

## Controles
- GAS: acelerar
- BRAKE: frenar/reversa
- ◀ / ▶: girar

## Compilación Android
El repositorio incluye un flujo de GitHub Actions. Sube el archivo ZIP de este proyecto al repositorio como `ProjectApexMobile.zip`, y añade el archivo de flujo de trabajo indicado en `workflow-template.yml` como `.github/workflows/android.yml`. La compilación publicará el APK como artefacto si el exportador Android está disponible en la imagen de Godot CI.

Este es un prototipo inicial, no un juego final. Debe compilarse y probarse en un dispositivo antes de considerarse jugable.
