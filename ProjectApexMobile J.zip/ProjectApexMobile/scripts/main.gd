extends Node3D

var car: Node3D
var camera: Camera3D
var speed := 0.0
var steering := 0.0
var heading := 0.0
var track_radius := 32.0
var throttle := false
var brake := false
var left := false
var right := false
var speed_label: Label
var hint_label: Label

func _ready() -> void:
	_build_world()
	_build_car()
	_build_ui()

func _build_world() -> void:
	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	environment.sky = Sky.new()
	environment.sky.sky_material = ProceduralSkyMaterial.new()
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.65, 0.72, 0.8)
	environment.ambient_light_energy = 0.7
	env.environment = environment
	add_child(env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -28, 0)
	sun.light_energy = 1.2
	add_child(sun)

	_add_box("Ground", Vector3(0, -0.6, 0), Vector3(180, 1, 180), Color(0.15, 0.34, 0.18))
	# Oval circuit made from a sequence of road segments.
	var road_material := _material(Color(0.12, 0.13, 0.15))
	var line_material := _material(Color(0.95, 0.88, 0.55))
	for i in range(64):
		var a := TAU * float(i) / 64.0
		var b := TAU * float(i + 1) / 64.0
		var p1 := Vector3(cos(a) * track_radius, 0.02, sin(a) * track_radius)
		var p2 := Vector3(cos(b) * track_radius, 0.02, sin(b) * track_radius)
		_add_road_segment(p1, p2, 12.0, road_material)
		var outer1 := Vector3(cos(a) * (track_radius + 6.3), 0.025, sin(a) * (track_radius + 6.3))
		var outer2 := Vector3(cos(b) * (track_radius + 6.3), 0.025, sin(b) * (track_radius + 6.3))
		_add_road_segment(outer1, outer2, 0.35, line_material)
		var inner1 := Vector3(cos(a) * (track_radius - 6.3), 0.025, sin(a) * (track_radius - 6.3))
		var inner2 := Vector3(cos(b) * (track_radius - 6.3), 0.025, sin(b) * (track_radius - 6.3))
		_add_road_segment(inner1, inner2, 0.35, line_material)

	# Simple scenery markers around the track.
	for i in range(24):
		var a := TAU * float(i) / 24.0
		var pos := Vector3(cos(a) * 48.0, 1.1, sin(a) * 48.0)
		_add_box("TrackMarker", pos, Vector3(0.7, 2.2, 0.7), Color(0.85, 0.18, 0.12))

func _build_car() -> void:
	car = Node3D.new()
	car.position = Vector3(0, 0.45, -track_radius)
	car.rotation.y = PI / 2.0
	add_child(car)
	_add_box_child(car, "Body", Vector3(0, 0.25, 0), Vector3(2.0, 0.55, 4.0), Color(0.04, 0.42, 0.95))
	_add_box_child(car, "Cabin", Vector3(0, 0.68, 0.25), Vector3(1.45, 0.5, 1.8), Color(0.08, 0.12, 0.17))
	for x in [-0.95, 0.95]:
		for z in [-1.25, 1.25]:
			_add_box_child(car, "Wheel", Vector3(x, 0.02, z), Vector3(0.35, 0.48, 0.72), Color(0.025, 0.025, 0.03))

	camera = Camera3D.new()
	camera.position = Vector3(0, 4.2, 8.5)
	camera.rotation_degrees = Vector3(-18, 180, 0)
	camera.current = true
	car.add_child(camera)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var panel := Control.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(panel)

	speed_label = Label.new()
	speed_label.position = Vector2(28, 22)
	speed_label.add_theme_font_size_override("font_size", 30)
	speed_label.add_theme_color_override("font_color", Color.WHITE)
	panel.add_child(speed_label)

	hint_label = Label.new()
	hint_label.text = "PROJECT APEX  •  PROTOTIPO  |  Mantén GAS para acelerar"
	hint_label.position = Vector2(28, 62)
	hint_label.add_theme_font_size_override("font_size", 16)
	hint_label.add_theme_color_override("font_color", Color(0.9, 0.94, 1.0))
	panel.add_child(hint_label)

	_make_button(panel, "◀", Vector2(28, -132), Vector2(90, 90), "left")
	_make_button(panel, "▶", Vector2(130, -132), Vector2(90, 90), "right")
	_make_button(panel, "BRAKE", Vector2(-220, -132), Vector2(90, 90), "brake")
	_make_button(panel, "GAS", Vector2(-118, -132), Vector2(90, 90), "gas")

func _make_button(parent: Control, caption: String, offset: Vector2, size: Vector2, action: String) -> void:
	var button := Button.new()
	button.text = caption
	button.size = size
	button.add_theme_font_size_override("font_size", 22)
	button.anchor_left = 0.0 if offset.x >= 0 else 1.0
	button.anchor_right = button.anchor_left
	button.anchor_top = 1.0
	button.anchor_bottom = 1.0
	button.position = offset
	if action == "brake" or action == "gas":
		button.anchor_left = 1.0
		button.anchor_right = 1.0
	button.button_down.connect(func(): _set_action(action, true))
	button.button_up.connect(func(): _set_action(action, false))
	parent.add_child(button)

func _set_action(action: String, value: bool) -> void:
	match action:
		"gas": throttle = value
		"brake": brake = value
		"left": left = value
		"right": right = value

func _physics_process(delta: float) -> void:
	if throttle:
		speed = move_toward(speed, 30.0, 13.0 * delta)
	elif brake:
		speed = move_toward(speed, -5.0, 22.0 * delta)
	else:
		speed = move_toward(speed, 0.0, 3.5 * delta)
	steering = float(right) - float(left)
	heading -= steering * (0.85 + abs(speed) * 0.035) * delta
	car.rotation.y = heading
	car.position.x += sin(heading) * speed * delta
	car.position.z += cos(heading) * speed * delta
	# Keep a simple chase camera aligned behind the car.
	var desired := car.global_position + car.global_basis * Vector3(0, 4.2, 8.5)
	camera.global_position = camera.global_position.lerp(desired, 4.0 * delta)
	camera.look_at(car.global_position + Vector3(0, 0.5, 0), Vector3.UP)
	speed_label.text = "APEX  |  %03d km/h" % int(abs(speed) * 6.0)

func _material(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	return m

func _add_box(node_name: String, pos: Vector3, dimensions: Vector3, color: Color) -> void:
	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	mesh_instance.mesh = mesh
	mesh_instance.position = pos
	mesh_instance.material_override = _material(color)
	add_child(mesh_instance)

func _add_box_child(parent: Node3D, node_name: String, pos: Vector3, dimensions: Vector3, color: Color) -> void:
	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	mesh_instance.mesh = mesh
	mesh_instance.position = pos
	mesh_instance.material_override = _material(color)
	parent.add_child(mesh_instance)

func _add_road_segment(p1: Vector3, p2: Vector3, width: float, material: Material) -> void:
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	var length := p1.distance_to(p2) + 0.25
	mesh.size = Vector3(width, 0.12, length)
	mesh_instance.mesh = mesh
	mesh_instance.position = (p1 + p2) * 0.5
	mesh_instance.position.y = 0.0
	mesh_instance.rotation.y = atan2(p2.x - p1.x, p2.z - p1.z)
	mesh_instance.material_override = material
	add_child(mesh_instance)
